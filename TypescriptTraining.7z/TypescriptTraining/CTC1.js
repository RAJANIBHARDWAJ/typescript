var ct = function (basic) {
    var hra = (20 * basic) / 100;
    var da = (10 * basic) / 100;
    var transport = 750;
    var pf = 500;
    var gross = (basic + hra + da + transport) - pf;
    var tax = (gross * 12) / 100;
    var net = gross - tax;
    console.log('Basic:' + basic * 12);
    console.log('hra:' + hra * 12);
    console.log('da:' + da * 12);
    console.log('transport:' + transport * 12);
    console.log('pf:' + pf * 12);
    console.log('tax:' + tax * 12);
    return net * 12;
};
console.log(ct(5000));
