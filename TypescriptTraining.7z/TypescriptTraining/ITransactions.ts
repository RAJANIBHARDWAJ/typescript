export interface ITransactions
{

    Widraw(amount:number,source:string)
    Deposit(amount:number,source:string)
}