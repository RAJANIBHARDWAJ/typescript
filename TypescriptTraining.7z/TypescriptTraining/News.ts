var news:string='news-capgemini'
console.log(news)