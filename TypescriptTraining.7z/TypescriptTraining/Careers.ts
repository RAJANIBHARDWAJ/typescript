var careers:string='career-capgemini'
console.log(careers)