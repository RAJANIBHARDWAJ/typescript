// class Employee
// {
//      firstname:string='rajani';
//      lastName:string='bhardwaj';
//      height:number=5.0;
     
//      display()
//      {
// return this.firstname+'  '+this.lastName+'  '+this.height;
         
//      }
// }
// var obj=new Employee();
// console.log(obj.firstname);
// console.log(obj.display());

//====================================

 export class Account
{

    accNo:number=101;
    accName:string='rajani'
    accBalance:number=6000;
 
    displayInterest(rate:number):number
    {
 
        return (this.accBalance*rate)*100;
    }
      
}
var acc=new Account();
console.log(acc.accBalance);