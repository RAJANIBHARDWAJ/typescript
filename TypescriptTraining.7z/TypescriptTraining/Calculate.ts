export interface Calculate
{

   add(n1:number,n2:number):number
    add1(n1:number,n2:number,othernumber:number[]):number
   
}

