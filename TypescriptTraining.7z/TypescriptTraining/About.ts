var header:string='about-Cagpemini';
console.log(header)