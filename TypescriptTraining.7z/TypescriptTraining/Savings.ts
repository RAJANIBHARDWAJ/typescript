import {Accounts} from './Accounts';
 
 class Savings extends Accounts{

 }
 var savObj=new Savings();
 savObj.accBalance=6000;
 console.log(savObj.deposite(18000));