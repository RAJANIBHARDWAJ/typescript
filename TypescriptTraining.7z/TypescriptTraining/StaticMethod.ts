

   static class CalImplement//
{

   

   static add1(n1:number,n2:number,othernumber?:number[]):number
    {
        var lastnumber=0;
        for(var i=0;i<othernumber.length;i++)
        {
         lastnumber=lastnumber+othernumber[i];

        }
        return n1+n2+lastnumber;
    }
    
}
var obj=new CalImplement();

console.log(CalImplement.add1(10,20,[2,2]));

