"use strict";
exports.__esModule = true;
var Employee_1 = require("./Employee");
var obj = new Employee_1.Account();
console.log(obj.displayInterest(10));
