"use strict";
// class Employee
// {
//      firstname:string='rajani';
//      lastName:string='bhardwaj';
//      height:number=5.0;
exports.__esModule = true;
//      display()
//      {
// return this.firstname+'  '+this.lastName+'  '+this.height;
//      }
// }
// var obj=new Employee();
// console.log(obj.firstname);
// console.log(obj.display());
//====================================
var Account = /** @class */ (function () {
    function Account() {
        this.accNo = 101;
        this.accName = 'rajani';
        this.accBalance = 6000;
    }
    Account.prototype.displayInterest = function (rate) {
        return (this.accBalance * rate) * 100;
    };
    return Account;
}());
exports.Account = Account;
var acc = new Account();
console.log(acc.accBalance);
