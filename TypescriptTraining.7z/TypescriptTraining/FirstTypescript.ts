var greetings='Welcome to Typescript';
console.log(greetings);

var firstName:string='rajani'
var lastName:string='shah';
var height:number=5.0;
var isPermanant:boolean=true;
var contact:any=245442425;
var newcontact:any='rajani.bhardwaj@capgemini.com';
console.log(firstName+' is a '+typeof(firstName));
console.log(contact+' is a '+typeof(contact));
console.log(newcontact+' is a '+typeof(newcontact));

function GreetUser():string
{
return 'welcome to function';

}
function Greet(name:string)
{
console.log('welcome:'+name)
}
 var f1=GreetUser();
 console.log(f1);
 console.log(Greet('rajani'));