var ct = function (basic) {
    var hra = 20 / 100 * basic;
    var da = 10 / 10 * basic;
    var transport = 750;
    var pf = 500;
    var tax = (basic + hra + da + transport) * 12 / 100;
    var anual = ((basic + hra + da + transport) * 12) - tax;
    console.log(anual);
    return 0;
};
console.log(ct(5000));
