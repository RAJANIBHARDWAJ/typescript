"use strict";
exports.__esModule = true;
var Accounts = /** @class */ (function () {
    function Accounts() {
        this.accBalance = 12000;
        this.accNo = 101;
    }
    Accounts.prototype.widraw = function (amount) {
        if (amount > 100) {
            this.accBalance = this.accBalance + amount;
            return this.accBalance;
        }
        else {
            return this.accBalance;
        }
    };
    //==================
    Accounts.prototype.deposite = function (amount) {
        if (amount > 100) {
            this.accBalance = this.accBalance + amount;
            return this.accBalance;
        }
        else {
            return this.accBalance;
        }
    };
    return Accounts;
}());
exports.Accounts = Accounts;
