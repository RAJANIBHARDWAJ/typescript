import {Account} from './Employee';
 var obj=new Account();
 console.log(obj.displayInterest(10));