export interface IBanking
{

    Widraw(amount:number):number;
    Deposit(amount:number):number;
    Request(something:string):boolean;
    Transfer(fromAccount:number,toAccount:number,amount:number):number
}