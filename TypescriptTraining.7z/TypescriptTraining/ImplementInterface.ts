import{ IBanking} from './BankingFunctionality'
class Savings implements IBanking
{
Widraw(amount:number):number
{
    return 10;
}

Deposit(amount:number):number
{
    return 10
}
Request(something:string):boolean
{
    return true;
}
Transfer(fromAccount:number,toAccount:number,amount:number):number
{return 10}
}