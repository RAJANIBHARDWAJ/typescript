export class Accounts
{
accBalance:number=12000;
accNo:number=101

widraw(amount:number):number
{ 

    if(amount>100)
    {
        this.accBalance=this.accBalance-amount;
        return this.accBalance;
    }
    else{
return this.accBalance;

    }
}
//==================
deposite(amount:number):number
{

    if(amount>100)
    {
        this.accBalance=this.accBalance+amount;
        return this.accBalance;
    }
    else{
return this.accBalance;

    }
}

}