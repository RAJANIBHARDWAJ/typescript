class Banking
{ 

    accountsInfo={
        accNo:101,
        accName:'rajani',
        accType:'savings',
        accBalance:5000
    };
    displayData()
    {
console.log(this.accountsInfo.accName+' '+this.accountsInfo.accBalance)

    }
    listofTechnologies=['.net','Angular','Node']
    displayTech()
    {

        console.log(this.listofTechnologies[0]);
        console.log(this.listofTechnologies[1]);
        console.log(this.listofTechnologies[2]);
    }
    addNewtech(techName:string)
    {
this.listofTechnologies.push(techName)
    }
    removeTech()
    {
        this.listofTechnologies.pop();
    }
}

var acc=new Banking();
console.log(acc.accountsInfo.accType);
console.log(acc.displayData());
console.log(acc.displayTech())
console.log(acc.removeTech())
console.log(acc.addNewtech('java'))
console.log(acc.displayTech())
