var Emp = /** @class */ (function () {
    function Emp() {
        this.EmployeeInfo = [
            { empNo: 101, empName: 'rajani', empsalary: 5000, empCity: 'goa' },
            { empNo: 102, empName: 'sneha', empsalary: 6000, empCity: 'pune' },
            { empNo: 103, empName: 'pooja', empsalary: 7000, empCity: 'delhi' }
        ];
    }
    Emp.prototype.displayInfo = function () {
        console.log(this.EmployeeInfo[0].empName, this.EmployeeInfo[1].empsalary, this.EmployeeInfo[2].empCity);
    };
    Emp.prototype.addNewEmp = function (empNo, empName, empsalary, empCity) {
        this.EmployeeInfo.push({ empNo: empNo, empName: empName, empsalary: empsalary, empCity: empCity });
    };
    Emp.prototype.removeEmp = function () {
        this.EmployeeInfo.pop();
    };
    //total number of EmployeeInfo
    Emp.prototype.totalEmp = function () {
        return this.EmployeeInfo.length;
    };
    //total salary paid to all the EmployeeInfo similar to push ,pop,there is a sort method,try it in case above is completed
    Emp.prototype.totalSalary = function () {
        var salary = 0;
        for (var i = 0; i < this.EmployeeInfo.length; i++) {
            var temp = this.EmployeeInfo.empsalary;
            salary = salary + temp;
        }
        return salary;
    };
    return Emp;
}());
var empObj = new Emp();
empObj.displayInfo();
empObj.removeEmp();
empObj.addNewEmp(104, 'komal', 9000, 'mumbai');
empObj.displayInfo();
console.log(empObj.totalEmp());
console.log(empObj.totalSalary());
