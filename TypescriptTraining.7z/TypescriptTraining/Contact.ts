var contact:string='contact -capgemini'
console.log(contact)