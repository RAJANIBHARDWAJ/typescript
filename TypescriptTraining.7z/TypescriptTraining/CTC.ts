

var ct=(basic:number):number =>
{
    var hra:number=20/100*basic;
    var da:number=10/10*basic;
    var transport:number=750;
    var pf:number=500;
    var tax:number=(basic+hra+da+transport)*12/100;
    var anual:Number=((basic+hra+da+transport)*12)-tax;


return anual;
}
console.log(ct(5000));