var Banking = /** @class */ (function () {
    function Banking() {
        this.accountsInfo = {
            accNo: 101,
            accName: 'rajani',
            accType: 'savings',
            accBalance: 5000
        };
        this.listofTechnologies = ['.net', 'Angular', 'Node'];
    }
    Banking.prototype.displayData = function () {
        console.log(this.accountsInfo.accName + ' ' + this.accountsInfo.accBalance);
    };
    Banking.prototype.displayTech = function () {
        console.log(this.listofTechnologies[0]);
        console.log(this.listofTechnologies[1]);
        console.log(this.listofTechnologies[2]);
    };
    Banking.prototype.addNewtech = function (techName) {
        this.listofTechnologies.push(techName);
    };
    Banking.prototype.removeTech = function () {
        this.listofTechnologies.pop();
    };
    return Banking;
}());
var acc = new Banking();
console.log(acc.accountsInfo.accType);
console.log(acc.displayData());
console.log(acc.displayTech());
console.log(acc.removeTech());
console.log(acc.displayTech());
console.log(acc.addNewtech('java'));
console.log(acc.displayTech());
