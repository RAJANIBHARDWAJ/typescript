function evenOdd(num) {
    if (num % 2 == 0)
        return 'even number';
    else
        return 'odd number';
}
var evenOd = evenOdd(3);
console.log(evenOd);
