function addNumbers(num1:number,num2:number,operate:string='+'):Number
{
var sum=0;
sum=num1+num2;
return sum;

}

var addition =addNumbers(3,4);
console.log(addition);

var add=(n1:number,n2:number):number => {

    console.log('Arrow function')
    return n1+n2;
} 
console.log(add(20,30));

var lambdagreetings=() =>{

    console.log('welcome !!!!!');return''
}
lambdagreetings();
var namegreetings=yourname=>{return 'welcome'+yourname}

