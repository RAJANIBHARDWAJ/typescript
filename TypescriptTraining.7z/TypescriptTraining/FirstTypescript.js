var greetings = 'Welcome to Typescript';
console.log(greetings);
var firstName = 'rajani';
var lastName = 'shah';
var height = 5.0;
var isPermanant = true;
var contact = 245442425;
var newcontact = 'rajani.bhardwaj@capgemini.com';
console.log(firstName + ' is a ' + typeof (firstName));
console.log(contact + ' is a ' + typeof (contact));
console.log(newcontact + ' is a ' + typeof (newcontact));
function GreetUser() {
    return 'welcome to function';
}
function Greet(name) {
     console.log('welcome:' + name);
}
var f1 = GreetUser();
console.log(f1);
console.log(Greet('rajani'));
