import {Calculate} from './Calculate'

class CalImplement implements Calculate
{

    add(n1:number,n2:number):number
    {
return n1+n2

    }

    add1(n1:number,n2:number,othernumber:number[]):number
    {
        var lastnumber=0;
        for(var i=0;i<othernumber.length;i++)
        {
         lastnumber=lastnumber+othernumber[i];

        }
        return n1+n2+lastnumber;
    }
    
}
var obj=new CalImplement();
console.log(obj.add(10,20));
console.log(obj.add1(10,20,[2,2]));
//second way
var mynumber:number[]=[56,8,9,9,9,10];
console.log(obj.add1(10,20,mynumber));
