
var ct=(basic:number):number =>
{
    var hra:number=(20*basic)/100;
    var da:number=(10*basic)/100;
    var transport:number=750;
    var pf:number=500;
    var gross=(basic+hra+da+transport)-pf;
    var tax:number=(gross*12)/100;
    var net=gross-tax;
   console.log('Basic:'+basic*12);
console.log('hra:'+hra*12);
console.log('da:'+da*12);
console.log('transport:'+transport*12);
console.log('pf:'+pf*12);
console.log('tax:'+tax*12);
return net*12;
}
console.log(ct(5000));