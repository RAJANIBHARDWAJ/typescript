import {ITransactions as tran} from './ITransactions'

import {IBanking} from './BankingFunctionality'
class BankAccount implements tran,IBanking
{

    Widraw(amount:number,source:number):number
    {
        return 320
    }
    Deposit(amount:number,source:number):number
    {
        return 10
    }

    //==============
IBanking.Widraw(amount:number):number
{
    return 10;
}

IBanking.Deposit(amount:number):number
{
    return 10
}
Request(something:string):boolean
{
    return true;
}
Transfer(fromAccount:number,toAccount:number,amount:number):number
{return 10}

    
}