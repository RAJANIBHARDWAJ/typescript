"use strict";
exports.__esModule = true;
var CalImplement = /** @class */ (function () {
    function CalImplement() {
    }
    CalImplement.prototype.add = function (n1, n2) {
        return n1 + n2;
    };
    CalImplement.prototype.add1 = function (n1, n2, othernumber) {
        var lastnumber = 0;
        for (var i = 0; i < othernumber.length; i++) {
            lastnumber = lastnumber + othernumber[i];
        }
        return n1 + n2 + lastnumber;
    };
    return CalImplement;
}());
var obj = new CalImplement();
console.log(obj.add(10, 20));
console.log(obj.add1(10, 20, [2, 2]));
//second way
var mynumber = [56, 8, 9, 9, 9, 10];
console.log(obj.add1(10, 20, mynumber));
